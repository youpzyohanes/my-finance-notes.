package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ExpenseItem
import com.example.data.model.ExpenseList
import com.example.data.model.ExpenseListWithItems
import com.example.export.BackupRestoreManager
import com.example.util.CurrencyFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("My Finance Notes", appName)
    }

    @Test
    fun testCurrencyFormatting() {
        assertEquals("Rp 150.000", CurrencyFormatter.formatRupiah(150000L))
        assertEquals("Rp 1.500.000", CurrencyFormatter.formatRupiah(1500000L))
        assertEquals("Rp 0", CurrencyFormatter.formatRupiah(0L))
        assertEquals(150000L, CurrencyFormatter.parseRupiah("Rp 150.000"))
        assertEquals(25000L, CurrencyFormatter.parseRupiah("25000"))
    }

    @Test
    fun testBackupAndRestoreJson() {
        val testList = listOf(
            ExpenseListWithItems(
                list = ExpenseList(id = 1, title = "Kebutuhan Harian", colorTheme = "YELLOW", displayOrder = 0),
                items = listOf(
                    ExpenseItem(id = 1, listId = 1, name = "Beras", amount = 120000L, displayOrder = 0),
                    ExpenseItem(id = 2, listId = 1, name = "Minyak", amount = 35000L, displayOrder = 1)
                )
            )
        )

        val json = BackupRestoreManager.exportToJson(testList)
        assertTrue(json.contains("Kebutuhan Harian"))
        assertTrue(json.contains("120000"))

        val parseResult = BackupRestoreManager.parseAndValidateJson(json)
        assertTrue(parseResult.isSuccess)
        val restored = parseResult.getOrThrow()
        assertEquals(1, restored.size)
        assertEquals("Kebutuhan Harian", restored[0].list.title)
        assertEquals(2, restored[0].items.size)
        assertEquals(155000L, restored[0].totalAmount)
    }
}
