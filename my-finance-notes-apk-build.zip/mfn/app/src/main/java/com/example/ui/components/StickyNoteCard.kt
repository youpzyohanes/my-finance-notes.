package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExpenseItem
import com.example.data.model.ExpenseListWithItems
import com.example.data.model.NoteColorTheme
import com.example.util.CurrencyFormatter

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StickyNoteCard(
    listWithItems: ExpenseListWithItems,
    isDark: Boolean,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onEditList: () -> Unit,
    onDeleteList: () -> Unit,
    onChangeColor: (NoteColorTheme) -> Unit,
    onAddItem: () -> Unit,
    onEditItem: (ExpenseItem) -> Unit,
    onDeleteItem: (ExpenseItem) -> Unit,
    onIncrementItem: (ExpenseItem) -> Unit,
    onDecrementItem: (ExpenseItem) -> Unit,
    onMoveItemUp: (Int) -> Unit,
    onMoveItemDown: (Int) -> Unit,
    onDownloadNote: () -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = listWithItems.colorTheme
    val cardBg = if (isDark) theme.cardColorDark else theme.cardColorLight
    val textColor = if (isDark) theme.textColorDark else theme.textColorLight
    val headerBg = if (isDark) theme.headerColorDark else theme.headerColorLight

    var showMenu by remember { mutableStateOf(false) }
    var showColorPicker by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 14.dp, bottom = 8.dp)
            .testTag("sticky_note_${listWithItems.list.id}")
    ) {
        // Sticky Note Card Container
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = if (isDark) Color(0x33FFFFFF) else Color(0x22000000),
                    shape = RoundedCornerShape(18.dp)
                )
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header Bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(headerBg)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = listWithItems.list.title,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = textColor,
                                fontSize = 20.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${listWithItems.items.size} item pengeluaran",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = textColor.copy(alpha = 0.7f)
                            )
                        )
                    }

                    // Quick Color Picker Button
                    IconButton(
                        onClick = { showColorPicker = !showColorPicker },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("color_picker_toggle_${listWithItems.list.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ColorLens,
                            contentDescription = "Ganti warna stiker",
                            tint = textColor.copy(alpha = 0.85f),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Reorder Up
                    IconButton(
                        onClick = onMoveUp,
                        enabled = canMoveUp,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("list_move_up_${listWithItems.list.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = "Pindah daftar ke atas",
                            tint = if (canMoveUp) textColor else textColor.copy(alpha = 0.25f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Reorder Down
                    IconButton(
                        onClick = onMoveDown,
                        enabled = canMoveDown,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("list_move_down_${listWithItems.list.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = "Pindah daftar ke bawah",
                            tint = if (canMoveDown) textColor else textColor.copy(alpha = 0.25f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // More Menu
                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("list_menu_${listWithItems.list.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Menu daftar",
                                tint = textColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Ubah Nama & Warna") },
                                onClick = {
                                    showMenu = false
                                    onEditList()
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Edit, contentDescription = null)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Download Stiker (PNG)") },
                                onClick = {
                                    showMenu = false
                                    onDownloadNote()
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Download, contentDescription = null)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Hapus Daftar Catatan", color = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showMenu = false
                                    onDeleteList()
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                }
                            )
                        }
                    }
                }

                // Expandable Color Picker Palette
                AnimatedVisibility(visible = showColorPicker) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(headerBg.copy(alpha = 0.7f))
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "Ganti Warna Stiker:",
                            style = MaterialTheme.typography.labelSmall,
                            color = textColor
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            NoteColorTheme.entries.forEach { colorOption ->
                                val isSelected = colorOption == theme
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(colorOption.cardColorLight)
                                        .border(
                                            width = if (isSelected) 3.dp else 1.dp,
                                            color = if (isSelected) colorOption.accentColor else Color(0x33000000),
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            onChangeColor(colorOption)
                                            showColorPicker = false
                                        }
                                )
                            }
                        }
                    }
                }

                // Items Content
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    val sorted = listWithItems.sortedItems

                    if (sorted.isEmpty()) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 18.dp)
                        ) {
                            Text(
                                text = "Belum ada item pengeluaran.\nTekan tombol di bawah untuk menambah.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = textColor.copy(alpha = 0.65f),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            )
                        }
                    } else {
                        sorted.forEachIndexed { index, item ->
                            ItemRow(
                                item = item,
                                theme = theme,
                                isDark = isDark,
                                canMoveUp = index > 0,
                                canMoveDown = index < sorted.size - 1,
                                onMoveUp = { onMoveItemUp(index) },
                                onMoveDown = { onMoveItemDown(index) },
                                onIncrement = { onIncrementItem(item) },
                                onDecrement = { onDecrementItem(item) },
                                onEdit = { onEditItem(item) },
                                onDelete = { onDeleteItem(item) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Total Calculation Banner (Calculated Automatically in Real-Time)
                    Surface(
                        color = if (isDark) Color(0x2E000000) else Color(0x22000000),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = "Total Daftar Ini:",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = textColor
                                )
                            )
                            Text(
                                text = CurrencyFormatter.formatRupiah(listWithItems.totalAmount),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = theme.accentColor,
                                    fontSize = 19.sp
                                ),
                                modifier = Modifier.testTag("list_total_${listWithItems.list.id}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Action Buttons: Tambah Item & Unduh Stiker
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = onAddItem,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = theme.accentColor
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("add_item_button_${listWithItems.list.id}")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tambah Item")
                        }

                        OutlinedButton(
                            onClick = onDownloadNote,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("download_note_button_${listWithItems.list.id}")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Unduh Stiker")
                        }
                    }
                }
            }
        }

        // Tactile Washi Tape Strip on Top Center
        Surface(
            color = theme.tapeColor,
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .rotate(-1.5f)
                .width(110.dp)
                .height(26.dp)
                .shadow(elevation = 2.dp, shape = RoundedCornerShape(4.dp))
        ) {}
    }
}
