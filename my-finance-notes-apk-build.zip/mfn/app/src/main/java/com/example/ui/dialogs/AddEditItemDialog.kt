package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.util.CurrencyFormatter

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditItemDialog(
    initialName: String = "",
    initialAmount: Long = 0L,
    isEdit: Boolean = false,
    onConfirm: (name: String, amount: Long) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var amountText by remember { mutableStateOf(if (initialAmount > 0) initialAmount.toString() else "") }
    var isNameError by remember { mutableStateOf(false) }

    val parsedAmount = CurrencyFormatter.parseRupiah(amountText)
    val quickAddAmounts = listOf(5_000L, 10_000L, 20_000L, 50_000L, 100_000L, 500_000L)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = if (isEdit) "Ubah Item Pengeluaran" else "Tambah Item Pengeluaran")
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        if (isNameError && it.isNotBlank()) isNameError = false
                    },
                    label = { Text("Nama Pengeluaran") },
                    placeholder = { Text("Contoh: Listrik, Bensin, Beras") },
                    isError = isNameError,
                    supportingText = {
                        if (isNameError) Text("Nama pengeluaran tidak boleh kosong")
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("item_name_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { input ->
                        val digits = input.filter { it.isDigit() }
                        amountText = digits
                    },
                    label = { Text("Nominal (Rupiah)") },
                    placeholder = { Text("Contoh: 150000") },
                    prefix = { Text("Rp ") },
                    supportingText = {
                        Text("Terformat: ${CurrencyFormatter.formatRupiah(parsedAmount)}")
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("item_amount_input")
                )

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Tambah Cepat (+ Nominal):",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickAddAmounts.forEach { quickVal ->
                        val label = when {
                            quickVal >= 1_000_000 -> "+${quickVal / 1_000_000} jt"
                            else -> "+${quickVal / 1_000} rb"
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer)
                                .clickable {
                                    val current = CurrencyFormatter.parseRupiah(amountText)
                                    amountText = (current + quickVal).toString()
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        isNameError = true
                    } else {
                        onConfirm(name.trim(), parsedAmount)
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("save_item_button")
            ) {
                Text(if (isEdit) "Simpan" else "Tambahkan")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_item_button")
            ) {
                Text("Batal")
            }
        }
    )
}
