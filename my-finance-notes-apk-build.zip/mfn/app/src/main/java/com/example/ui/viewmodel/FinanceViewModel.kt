package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.ExpenseItem
import com.example.data.model.ExpenseList
import com.example.data.model.ExpenseListWithItems
import com.example.data.model.NoteColorTheme
import com.example.data.repository.ExpenseRepository
import com.example.export.BackupRestoreManager
import com.example.export.ExportResolution
import com.example.export.StickyNoteImageExporter
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiNotification(
    val message: String,
    val isError: Boolean = false
)

class FinanceViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ExpenseRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ExpenseRepository(db.expenseDao())
    }

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _notification = MutableSharedFlow<UiNotification>()
    val notification: SharedFlow<UiNotification> = _notification.asSharedFlow()

    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    val rawLists: StateFlow<List<ExpenseListWithItems>> = repository.allListsWithItems
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val filteredLists: StateFlow<List<ExpenseListWithItems>> = combine(rawLists, _searchQuery) { lists, query ->
        if (query.isBlank()) {
            lists
        } else {
            val q = query.trim().lowercase()
            lists.filter { listWithItems ->
                listWithItems.list.title.lowercase().contains(q) ||
                    listWithItems.items.any { it.name.lowercase().contains(q) }
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val grandTotal: StateFlow<Long> = rawLists.combine(rawLists) { lists, _ ->
        lists.sumOf { it.totalAmount }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0L
    )

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun addList(title: String, colorTheme: NoteColorTheme) {
        if (title.isBlank()) {
            notify("Nama daftar tidak boleh kosong", isError = true)
            return
        }
        viewModelScope.launch {
            try {
                val order = rawLists.value.size
                repository.addList(title, colorTheme, order)
                notify("Daftar '$title' berhasil dibuat")
            } catch (e: Exception) {
                notify("Gagal membuat daftar: ${e.localizedMessage}", isError = true)
            }
        }
    }

    fun updateList(listId: Long, title: String, colorTheme: NoteColorTheme) {
        if (title.isBlank()) {
            notify("Nama daftar tidak boleh kosong", isError = true)
            return
        }
        viewModelScope.launch {
            try {
                repository.updateListTitle(listId, title)
                repository.updateListColor(listId, colorTheme)
                notify("Daftar berhasil diperbarui")
            } catch (e: Exception) {
                notify("Gagal memperbarui: ${e.localizedMessage}", isError = true)
            }
        }
    }

    fun deleteList(listId: Long, title: String) {
        viewModelScope.launch {
            try {
                repository.deleteList(listId)
                notify("Daftar '$title' telah dihapus")
            } catch (e: Exception) {
                notify("Gagal menghapus daftar", isError = true)
            }
        }
    }

    fun updateListColor(listId: Long, colorTheme: NoteColorTheme) {
        viewModelScope.launch {
            repository.updateListColor(listId, colorTheme)
        }
    }

    fun addItem(listId: Long, name: String, amount: Long) {
        if (name.isBlank()) {
            notify("Nama pengeluaran tidak boleh kosong", isError = true)
            return
        }
        viewModelScope.launch {
            try {
                val list = rawLists.value.firstOrNull { it.list.id == listId }
                val nextOrder = list?.items?.size ?: 0
                repository.addItem(listId, name, amount, nextOrder)
                notify("Item '$name' ditambahkan")
            } catch (e: Exception) {
                notify("Gagal menambahkan item", isError = true)
            }
        }
    }

    fun updateItem(itemId: Long, listId: Long, name: String, amount: Long, order: Int) {
        if (name.isBlank()) {
            notify("Nama pengeluaran tidak boleh kosong", isError = true)
            return
        }
        viewModelScope.launch {
            try {
                repository.updateItem(itemId, listId, name, amount, order)
                notify("Item '$name' diperbarui")
            } catch (e: Exception) {
                notify("Gagal memperbarui item", isError = true)
            }
        }
    }

    fun deleteItem(itemId: Long, name: String) {
        viewModelScope.launch {
            try {
                repository.deleteItem(itemId)
                notify("Item '$name' dihapus")
            } catch (e: Exception) {
                notify("Gagal menghapus item", isError = true)
            }
        }
    }

    fun adjustItemAmount(itemId: Long, currentAmount: Long, delta: Long) {
        viewModelScope.launch {
            repository.adjustItemAmount(itemId, currentAmount, delta)
        }
    }

    fun moveItemUp(listWithItems: ExpenseListWithItems, currentIndex: Int) {
        if (currentIndex <= 0) return
        val items = listWithItems.sortedItems.toMutableList()
        val temp = items[currentIndex]
        items[currentIndex] = items[currentIndex - 1]
        items[currentIndex - 1] = temp
        viewModelScope.launch {
            repository.reorderItems(items)
        }
    }

    fun moveItemDown(listWithItems: ExpenseListWithItems, currentIndex: Int) {
        val items = listWithItems.sortedItems.toMutableList()
        if (currentIndex >= items.size - 1) return
        val temp = items[currentIndex]
        items[currentIndex] = items[currentIndex + 1]
        items[currentIndex + 1] = temp
        viewModelScope.launch {
            repository.reorderItems(items)
        }
    }

    fun moveListUp(currentIndex: Int) {
        if (currentIndex <= 0) return
        val lists = rawLists.value.map { it.list }.toMutableList()
        val temp = lists[currentIndex]
        lists[currentIndex] = lists[currentIndex - 1]
        lists[currentIndex - 1] = temp
        viewModelScope.launch {
            repository.reorderLists(lists)
        }
    }

    fun moveListDown(currentIndex: Int) {
        val lists = rawLists.value.map { it.list }.toMutableList()
        if (currentIndex >= lists.size - 1) return
        val temp = lists[currentIndex]
        lists[currentIndex] = lists[currentIndex + 1]
        lists[currentIndex + 1] = temp
        viewModelScope.launch {
            repository.reorderLists(lists)
        }
    }

    fun downloadSingleNote(
        context: Context,
        listWithItems: ExpenseListWithItems,
        resolution: ExportResolution,
        saveToGallery: Boolean,
        shareToWhatsApp: Boolean
    ) {
        viewModelScope.launch {
            _isExporting.value = true
            try {
                val bitmaps = StickyNoteImageExporter.exportSingleList(context, listWithItems, resolution)
                val baseName = "Catatan_${listWithItems.list.title.replace("\\s+".toRegex(), "_")}"

                if (saveToGallery) {
                    val saveResult = StickyNoteImageExporter.saveBitmapsToGallery(context, bitmaps, baseName)
                    if (saveResult.isSuccess) {
                        notify("Gambar stiker berhasil disimpan ke Galeri!")
                    } else {
                        notify("Gagal menyimpan ke galeri", isError = true)
                    }
                }

                if (shareToWhatsApp) {
                    val prepResult = StickyNoteImageExporter.prepareBitmapsForSharing(context, bitmaps, baseName)
                    prepResult.onSuccess { uris ->
                        StickyNoteImageExporter.launchShareIntent(context, uris, listWithItems.list.title, toWhatsApp = true)
                    }.onFailure {
                        notify("Gagal menyiapkan gambar untuk dibagikan", isError = true)
                    }
                }
            } catch (e: Exception) {
                notify("Gagal memproses gambar: ${e.localizedMessage}", isError = true)
            } finally {
                _isExporting.value = false
            }
        }
    }

    fun downloadAllNotes(
        context: Context,
        resolution: ExportResolution,
        saveToGallery: Boolean,
        shareToWhatsApp: Boolean
    ) {
        val all = rawLists.value
        if (all.isEmpty()) {
            notify("Tidak ada catatan untuk diunduh", isError = true)
            return
        }

        viewModelScope.launch {
            _isExporting.value = true
            try {
                val bitmaps = StickyNoteImageExporter.exportAllLists(context, all, resolution)
                val baseName = "Semua_Catatan_Pengeluaran"

                if (saveToGallery) {
                    val saveResult = StickyNoteImageExporter.saveBitmapsToGallery(context, bitmaps, baseName)
                    if (saveResult.isSuccess) {
                        notify("${bitmaps.size} papan stiker berhasil disimpan ke Galeri!")
                    } else {
                        notify("Gagal menyimpan ke galeri", isError = true)
                    }
                }

                if (shareToWhatsApp) {
                    val prepResult = StickyNoteImageExporter.prepareBitmapsForSharing(context, bitmaps, baseName)
                    prepResult.onSuccess { uris ->
                        StickyNoteImageExporter.launchShareIntent(context, uris, "Semua Pengeluaran", toWhatsApp = true)
                    }.onFailure {
                        notify("Gagal menyiapkan gambar untuk dibagikan", isError = true)
                    }
                }
            } catch (e: Exception) {
                notify("Gagal memproses gambar: ${e.localizedMessage}", isError = true)
            } finally {
                _isExporting.value = false
            }
        }
    }

    fun getBackupJson(): String {
        return BackupRestoreManager.exportToJson(rawLists.value)
    }

    fun restoreBackup(jsonString: String, overwrite: Boolean, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = BackupRestoreManager.parseAndValidateJson(jsonString)
            result.onSuccess { parsed ->
                try {
                    repository.restoreData(parsed, overwrite)
                    val count = parsed.size
                    notify("Berhasil memulihkan $count daftar catatan!")
                    onComplete(true, "Berhasil memulihkan $count daftar catatan.")
                } catch (e: Exception) {
                    notify("Gagal menyimpan data: ${e.localizedMessage}", isError = true)
                    onComplete(false, "Gagal menyimpan: ${e.localizedMessage}")
                }
            }.onFailure { err ->
                notify(err.message ?: "Data backup tidak valid", isError = true)
                onComplete(false, err.message ?: "Format data tidak valid")
            }
        }
    }

    fun resetToDemoData() {
        viewModelScope.launch {
            try {
                repository.resetToDemoData()
                notify("Contoh data berhasil dimuat ulang")
            } catch (e: Exception) {
                notify("Gagal memuat contoh data", isError = true)
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            try {
                repository.clearAllData()
                notify("Seluruh data telah dihapus")
            } catch (e: Exception) {
                notify("Gagal menghapus data", isError = true)
            }
        }
    }

    private fun notify(message: String, isError: Boolean = false) {
        viewModelScope.launch {
            _notification.emit(UiNotification(message, isError))
        }
    }
}
