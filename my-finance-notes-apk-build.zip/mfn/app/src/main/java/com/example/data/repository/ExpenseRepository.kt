package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.ExpenseDao
import com.example.data.model.ExpenseItem
import com.example.data.model.ExpenseList
import com.example.data.model.ExpenseListWithItems
import com.example.data.model.NoteColorTheme
import kotlinx.coroutines.flow.Flow

class ExpenseRepository(private val expenseDao: ExpenseDao) {

    val allListsWithItems: Flow<List<ExpenseListWithItems>> = expenseDao.getAllListsWithItems()

    suspend fun addList(title: String, colorTheme: NoteColorTheme = NoteColorTheme.YELLOW, order: Int = 0): Long {
        val list = ExpenseList(
            title = title.trim(),
            colorTheme = colorTheme.idName,
            displayOrder = order
        )
        return expenseDao.insertList(list)
    }

    suspend fun updateListTitle(listId: Long, title: String) {
        expenseDao.updateListTitle(listId, title.trim())
    }

    suspend fun updateListColor(listId: Long, colorTheme: NoteColorTheme) {
        expenseDao.updateListColor(listId, colorTheme.idName)
    }

    suspend fun deleteList(listId: Long) {
        expenseDao.deleteListById(listId)
    }

    suspend fun addItem(listId: Long, name: String, amount: Long, order: Int = 0): Long {
        val safeAmount = if (amount < 0) 0L else amount
        val item = ExpenseItem(
            listId = listId,
            name = name.trim(),
            amount = safeAmount,
            displayOrder = order
        )
        return expenseDao.insertItem(item)
    }

    suspend fun updateItem(itemId: Long, listId: Long, name: String, amount: Long, order: Int) {
        val safeAmount = if (amount < 0) 0L else amount
        val item = ExpenseItem(
            id = itemId,
            listId = listId,
            name = name.trim(),
            amount = safeAmount,
            displayOrder = order
        )
        expenseDao.updateItem(item)
    }

    suspend fun updateItemAmount(itemId: Long, newAmount: Long) {
        val safeAmount = if (newAmount < 0) 0L else newAmount
        expenseDao.updateItemAmount(itemId, safeAmount)
    }

    suspend fun adjustItemAmount(itemId: Long, currentAmount: Long, delta: Long) {
        val updated = currentAmount + delta
        val safeAmount = if (updated < 0) 0L else updated
        expenseDao.updateItemAmount(itemId, safeAmount)
    }

    suspend fun deleteItem(itemId: Long) {
        expenseDao.deleteItemById(itemId)
    }

    suspend fun reorderLists(reordered: List<ExpenseList>) {
        reordered.forEachIndexed { index, list ->
            expenseDao.updateListOrder(list.id, index)
        }
    }

    suspend fun reorderItems(reordered: List<ExpenseItem>) {
        reordered.forEachIndexed { index, item ->
            expenseDao.updateItemOrder(item.id, index)
        }
    }

    suspend fun clearAllData() {
        expenseDao.clearAllData()
    }

    suspend fun resetToDemoData() {
        expenseDao.clearAllData()
        AppDatabase.populateInitialDemoData(expenseDao)
    }

    suspend fun restoreData(imported: List<ExpenseListWithItems>, overwrite: Boolean) {
        if (overwrite) {
            expenseDao.clearAllData()
        }
        imported.forEachIndexed { listIdx, listWithItems ->
            val newListId = expenseDao.insertList(
                ExpenseList(
                    title = listWithItems.list.title,
                    colorTheme = listWithItems.list.colorTheme,
                    displayOrder = listIdx
                )
            )
            listWithItems.items.forEachIndexed { itemIdx, item ->
                expenseDao.insertItem(
                    ExpenseItem(
                        listId = newListId,
                        name = item.name,
                        amount = item.amount,
                        displayOrder = itemIdx
                    )
                )
            }
        }
    }
}
