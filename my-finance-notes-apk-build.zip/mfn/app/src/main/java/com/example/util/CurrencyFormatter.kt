package com.example.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CurrencyFormatter {

    fun formatRupiah(amount: Long): String {
        return try {
            val formattedNumber = String.format(Locale.GERMANY, "%,d", amount)
            "Rp $formattedNumber"
        } catch (_: Exception) {
            "Rp $amount"
        }
    }

    fun parseRupiah(text: String): Long {
        val cleaned = text.replace("[^0-9]".toRegex(), "")
        return cleaned.toLongOrNull() ?: 0L
    }

    fun formatDateTime(timestamp: Long = System.currentTimeMillis()): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm 'WIB'", Locale("id", "ID"))
        return sdf.format(Date(timestamp))
    }

    fun formatDateShort(timestamp: Long = System.currentTimeMillis()): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale("id", "ID"))
        return sdf.format(Date(timestamp))
    }
}
