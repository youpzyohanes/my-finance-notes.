package com.example.export

import com.example.data.model.ExpenseItem
import com.example.data.model.ExpenseList
import com.example.data.model.ExpenseListWithItems
import com.example.data.model.NoteColorTheme
import com.example.util.CurrencyFormatter
import org.json.JSONArray
import org.json.JSONObject

object BackupRestoreManager {

    fun exportToJson(lists: List<ExpenseListWithItems>): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("appName", "My Finance Notes")
        root.put("exportedAt", System.currentTimeMillis())
        root.put("exportedDate", CurrencyFormatter.formatDateTime())

        val listsArray = JSONArray()
        lists.forEach { listWithItems ->
            val listObj = JSONObject()
            listObj.put("title", listWithItems.list.title)
            listObj.put("colorTheme", listWithItems.list.colorTheme)
            listObj.put("displayOrder", listWithItems.list.displayOrder)

            val itemsArray = JSONArray()
            listWithItems.sortedItems.forEach { item ->
                val itemObj = JSONObject()
                itemObj.put("name", item.name)
                itemObj.put("amount", item.amount)
                itemObj.put("displayOrder", item.displayOrder)
                itemsArray.put(itemObj)
            }
            listObj.put("items", itemsArray)
            listsArray.put(listObj)
        }
        root.put("lists", listsArray)

        return root.toString(2)
    }

    fun parseAndValidateJson(jsonString: String): Result<List<ExpenseListWithItems>> {
        return try {
            val root = JSONObject(jsonString)
            if (!root.has("lists")) {
                return Result.failure(IllegalArgumentException("Format file tidak valid: data 'lists' tidak ditemukan."))
            }

            val listsArray = root.getJSONArray("lists")
            val parsedLists = mutableListOf<ExpenseListWithItems>()

            for (i in 0 until listsArray.length()) {
                val listObj = listsArray.getJSONObject(i)
                val title = listObj.optString("title", "Catatan Tanpa Nama").trim()
                val colorTheme = listObj.optString("colorTheme", NoteColorTheme.YELLOW.idName)
                val displayOrder = listObj.optInt("displayOrder", i)

                val expenseList = ExpenseList(
                    title = if (title.isBlank()) "Daftar #${i + 1}" else title,
                    colorTheme = colorTheme,
                    displayOrder = displayOrder
                )

                val itemsList = mutableListOf<ExpenseItem>()
                val itemsArray = listObj.optJSONArray("items")
                if (itemsArray != null) {
                    for (j in 0 until itemsArray.length()) {
                        val itemObj = itemsArray.getJSONObject(j)
                        val name = itemObj.optString("name", "Pengeluaran").trim()
                        val amount = itemObj.optLong("amount", 0L)
                        val itemOrder = itemObj.optInt("displayOrder", j)

                        itemsList.add(
                            ExpenseItem(
                                listId = 0L,
                                name = if (name.isBlank()) "Item #${j + 1}" else name,
                                amount = if (amount < 0) 0L else amount,
                                displayOrder = itemOrder
                            )
                        )
                    }
                }

                parsedLists.add(ExpenseListWithItems(list = expenseList, items = itemsList))
            }

            if (parsedLists.isEmpty()) {
                Result.failure(IllegalArgumentException("Tidak ada daftar pengeluaran yang ditemukan dalam file."))
            } else {
                Result.success(parsedLists)
            }
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("Gagal membaca data JSON: ${e.localizedMessage ?: "Format tidak cocok"}"))
        }
    }
}
