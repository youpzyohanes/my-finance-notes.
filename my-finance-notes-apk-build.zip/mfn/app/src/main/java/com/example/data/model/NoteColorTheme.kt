package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class NoteColorTheme(
    val idName: String,
    val displayName: String,
    val cardColorLight: Color,
    val cardColorDark: Color,
    val headerColorLight: Color,
    val headerColorDark: Color,
    val textColorLight: Color,
    val textColorDark: Color,
    val accentColor: Color,
    val tapeColor: Color,
    val colorIntLight: Int,
    val colorIntDark: Int,
    val textIntLight: Int,
    val textIntDark: Int
) {
    YELLOW(
        idName = "YELLOW",
        displayName = "Kuning Pastel",
        cardColorLight = Color(0xFFFFF9C4), // Soft pastel yellow
        cardColorDark = Color(0xFF332F1A),
        headerColorLight = Color(0xFFFFF59D),
        headerColorDark = Color(0xFF423D24),
        textColorLight = Color(0xFF3E2723),
        textColorDark = Color(0xFFFFF8E1),
        accentColor = Color(0xFFF57F17),
        tapeColor = Color(0x99FFE082),
        colorIntLight = 0xFFFFF9C4.toInt(),
        colorIntDark = 0xFF332F1A.toInt(),
        textIntLight = 0xFF3E2723.toInt(),
        textIntDark = 0xFFFFF8E1.toInt()
    ),
    CREAM(
        idName = "CREAM",
        displayName = "Krem Hangat",
        cardColorLight = Color(0xFFFFF8E1),
        cardColorDark = Color(0xFF362F24),
        headerColorLight = Color(0xFFFFECB3),
        headerColorDark = Color(0xFF453D30),
        textColorLight = Color(0xFF423425),
        textColorDark = Color(0xFFFFECB3),
        accentColor = Color(0xFFFF8F00),
        tapeColor = Color(0x99FFE0B2),
        colorIntLight = 0xFFFFF8E1.toInt(),
        colorIntDark = 0xFF362F24.toInt(),
        textIntLight = 0xFF423425.toInt(),
        textIntDark = 0xFFFFECB3.toInt()
    ),
    MINT(
        idName = "MINT",
        displayName = "Hijau Mint",
        cardColorLight = Color(0xFFE8F5E9),
        cardColorDark = Color(0xFF1E3324),
        headerColorLight = Color(0xFFC8E6C9),
        headerColorDark = Color(0xFF2B4432),
        textColorLight = Color(0xFF1B5E20),
        textColorDark = Color(0xFFE8F5E9),
        accentColor = Color(0xFF2E7D32),
        tapeColor = Color(0x99A5D6A7),
        colorIntLight = 0xFFE8F5E9.toInt(),
        colorIntDark = 0xFF1E3324.toInt(),
        textIntLight = 0xFF1B5E20.toInt(),
        textIntDark = 0xFFE8F5E9.toInt()
    ),
    BLUE(
        idName = "BLUE",
        displayName = "Biru Muda",
        cardColorLight = Color(0xFFE1F5FE),
        cardColorDark = Color(0xFF1A2E3D),
        headerColorLight = Color(0xFFB3E5FC),
        headerColorDark = Color(0xFF263F52),
        textColorLight = Color(0xFF0D47A1),
        textColorDark = Color(0xFFE1F5FE),
        accentColor = Color(0xFF0288D1),
        tapeColor = Color(0x9990CAF9),
        colorIntLight = 0xFFE1F5FE.toInt(),
        colorIntDark = 0xFF1A2E3D.toInt(),
        textIntLight = 0xFF0D47A1.toInt(),
        textIntDark = 0xFFE1F5FE.toInt()
    ),
    PINK(
        idName = "PINK",
        displayName = "Merah Muda",
        cardColorLight = Color(0xFFFCE4EC),
        cardColorDark = Color(0xFF3B1E29),
        headerColorLight = Color(0xFFF8BBD0),
        headerColorDark = Color(0xFF4D2B37),
        textColorLight = Color(0xFF880E4F),
        textColorDark = Color(0xFFFCE4EC),
        accentColor = Color(0xFFC2185B),
        tapeColor = Color(0x99F48FB1),
        colorIntLight = 0xFFFCE4EC.toInt(),
        colorIntDark = 0xFF3B1E29.toInt(),
        textIntLight = 0xFF880E4F.toInt(),
        textIntDark = 0xFFFCE4EC.toInt()
    ),
    LAVENDER(
        idName = "LAVENDER",
        displayName = "Ungu Lilac",
        cardColorLight = Color(0xFFF3E5F5),
        cardColorDark = Color(0xFF321E3B),
        headerColorLight = Color(0xFFE1BEE7),
        headerColorDark = Color(0xFF452B52),
        textColorLight = Color(0xFF4A148C),
        textColorDark = Color(0xFFF3E5F5),
        accentColor = Color(0xFF7B1FA2),
        tapeColor = Color(0x99CE93D8),
        colorIntLight = 0xFFF3E5F5.toInt(),
        colorIntDark = 0xFF321E3B.toInt(),
        textIntLight = 0xFF4A148C.toInt(),
        textIntDark = 0xFFF3E5F5.toInt()
    ),
    PEACH(
        idName = "PEACH",
        displayName = "Peach Manis",
        cardColorLight = Color(0xFFFFF3E0),
        cardColorDark = Color(0xFF3D271B),
        headerColorLight = Color(0xFFFFE0B2),
        headerColorDark = Color(0xFF4E3526),
        textColorLight = Color(0xFFBF360C),
        textColorDark = Color(0xFFFFF3E0),
        accentColor = Color(0xFFE65100),
        tapeColor = Color(0x99FFCC80),
        colorIntLight = 0xFFFFF3E0.toInt(),
        colorIntDark = 0xFF3D271B.toInt(),
        textIntLight = 0xFFBF360C.toInt(),
        textIntDark = 0xFFFFF3E0.toInt()
    );

    companion object {
        fun fromId(id: String?): NoteColorTheme {
            return entries.firstOrNull { it.idName.equals(id, ignoreCase = true) } ?: YELLOW
        }
    }
}
