package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AmberPrimary = Color(0xFFF57F17)
val AmberSecondary = Color(0xFFE65100)
val AmberTertiary = Color(0xFF2E7D32)

val LightBackground = Color(0xFFFAF7F2)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF2ECE1)
val LightOnSurface = Color(0xFF2C2523)

val DarkBackground = Color(0xFF191614)
val DarkSurface = Color(0xFF231F1D)
val DarkSurfaceVariant = Color(0xFF332D28)
val DarkOnSurface = Color(0xFFF5EFE9)
