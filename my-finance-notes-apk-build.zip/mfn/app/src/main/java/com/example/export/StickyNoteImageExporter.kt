package com.example.export

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.model.ExpenseItem
import com.example.data.model.ExpenseListWithItems
import com.example.data.model.NoteColorTheme
import com.example.util.CurrencyFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import kotlin.math.min

enum class ExportResolution(val label: String, val scaleFactor: Float) {
    STANDARD("Standar (1x)", 1.0f),
    LARGE("Besar (1.5x)", 1.5f),
    ULTRA("Resolusi Tinggi (2x)", 2.0f)
}

object StickyNoteImageExporter {

    private const val MAX_ITEMS_PER_PAGE = 12

    suspend fun exportSingleList(
        context: Context,
        listWithItems: ExpenseListWithItems,
        resolution: ExportResolution
    ): List<Bitmap> = withContext(Dispatchers.Default) {
        val items = listWithItems.sortedItems
        val totalPages = if (items.isEmpty()) 1 else ((items.size - 1) / MAX_ITEMS_PER_PAGE) + 1
        val bitmaps = mutableListOf<Bitmap>()

        for (pageIndex in 0 until totalPages) {
            val startIdx = pageIndex * MAX_ITEMS_PER_PAGE
            val endIdx = min(startIdx + MAX_ITEMS_PER_PAGE, items.size)
            val pageItems = if (items.isNotEmpty()) items.subList(startIdx, endIdx) else emptyList()

            val bitmap = renderStickyNoteBitmap(
                listWithItems = listWithItems,
                pageItems = pageItems,
                pageNumber = pageIndex + 1,
                totalPages = totalPages,
                scale = resolution.scaleFactor
            )
            bitmaps.add(bitmap)
        }
        bitmaps
    }

    suspend fun exportAllLists(
        context: Context,
        allLists: List<ExpenseListWithItems>,
        resolution: ExportResolution
    ): List<Bitmap> = withContext(Dispatchers.Default) {
        val grandTotal = allLists.sumOf { it.totalAmount }
        val bitmaps = mutableListOf<Bitmap>()

        // Multi-page summary board: 2 sticky notes per board sheet, or 1 if long
        val chunked = allLists.chunked(2)
        val totalSheets = if (chunked.isEmpty()) 1 else chunked.size

        chunked.forEachIndexed { sheetIndex, listsForSheet ->
            val bitmap = renderSummaryBoardBitmap(
                lists = listsForSheet,
                grandTotal = grandTotal,
                sheetNumber = sheetIndex + 1,
                totalSheets = totalSheets,
                scale = resolution.scaleFactor
            )
            bitmaps.add(bitmap)
        }

        if (bitmaps.isEmpty()) {
            bitmaps.add(
                renderSummaryBoardBitmap(
                    lists = emptyList(),
                    grandTotal = 0L,
                    sheetNumber = 1,
                    totalSheets = 1,
                    scale = resolution.scaleFactor
                )
            )
        }

        bitmaps
    }

    private fun renderStickyNoteBitmap(
        listWithItems: ExpenseListWithItems,
        pageItems: List<ExpenseItem>,
        pageNumber: Int,
        totalPages: Int,
        scale: Float
    ): Bitmap {
        val baseWidth = 840f
        val baseHeight = 1050f
        val width = (baseWidth * scale).toInt()
        val height = (baseHeight * scale).toInt()

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val theme = listWithItems.colorTheme
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // 1. Warm table / desk background
        canvas.drawColor(0xFFF3EFEA.toInt())

        // 2. Note Shadow
        val margin = 50f * scale
        val noteLeft = margin
        val noteTop = margin + (30f * scale)
        val noteRight = (baseWidth - 50f) * scale
        val noteBottom = (baseHeight - 50f) * scale
        val cornerRadius = 24f * scale

        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x24000000
            style = Paint.Style.FILL
        }
        val shadowRect = RectF(noteLeft + 8f * scale, noteTop + 14f * scale, noteRight + 8f * scale, noteBottom + 14f * scale)
        canvas.drawRoundRect(shadowRect, cornerRadius, cornerRadius, shadowPaint)

        // 3. Sticky Note Body
        val notePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.colorIntLight
            style = Paint.Style.FILL
        }
        val noteRect = RectF(noteLeft, noteTop, noteRight, noteBottom)
        canvas.drawRoundRect(noteRect, cornerRadius, cornerRadius, notePaint)

        // Note subtle fold corner at bottom-right
        val foldSize = 36f * scale
        val foldPath = Path().apply {
            moveTo(noteRight - foldSize, noteBottom)
            lineTo(noteRight, noteBottom - foldSize)
            lineTo(noteRight - foldSize, noteBottom - foldSize)
            close()
        }
        val foldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x33000000
            style = Paint.Style.FILL
        }
        canvas.drawPath(foldPath, foldPaint)

        // 4. Washi Tape at Top Center
        val tapeWidth = 180f * scale
        val tapeHeight = 44f * scale
        val tapeLeft = (baseWidth * scale - tapeWidth) / 2f
        val tapeTop = margin - (5f * scale)
        val tapePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xAAFFE082.toInt()
            style = Paint.Style.FILL
        }
        val tapeRect = RectF(tapeLeft, tapeTop, tapeLeft + tapeWidth, tapeTop + tapeHeight)
        canvas.save()
        canvas.rotate(-2f, tapeLeft + tapeWidth / 2f, tapeTop + tapeHeight / 2f)
        canvas.drawRoundRect(tapeRect, 6f * scale, 6f * scale, tapePaint)
        canvas.restore()

        // 5. Header: Title & Page info
        var currentY = noteTop + (55f * scale)

        // Category Tag
        paint.color = theme.textIntLight
        paint.alpha = 180
        paint.textSize = 18f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.LEFT
        val pageText = if (totalPages > 1) " • Hal $pageNumber/$totalPages" else ""
        canvas.drawText("CATATAN PENGELUARAN$pageText", noteLeft + (40f * scale), currentY, paint)

        // List Title
        currentY += 40f * scale
        paint.alpha = 255
        paint.textSize = 34f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val titleText = listWithItems.list.title
        canvas.drawText(titleText, noteLeft + (40f * scale), currentY, paint)

        // Divider
        currentY += 24f * scale
        paint.color = theme.textIntLight
        paint.alpha = 60
        paint.strokeWidth = 2f * scale
        paint.style = Paint.Style.STROKE
        canvas.drawLine(noteLeft + (40f * scale), currentY, noteRight - (40f * scale), currentY, paint)

        // 6. Items list
        paint.style = Paint.Style.FILL
        currentY += 40f * scale

        if (pageItems.isEmpty()) {
            paint.color = theme.textIntLight
            paint.alpha = 140
            paint.textSize = 22f * scale
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            canvas.drawText("Belum ada item pengeluaran", noteLeft + (40f * scale), currentY + 30f * scale, paint)
        } else {
            val itemSpacing = 42f * scale
            val leftX = noteLeft + (40f * scale)
            val rightX = noteRight - (40f * scale)

            pageItems.forEachIndexed { idx, item ->
                val rowY = currentY + (idx * itemSpacing)

                // Bullet point
                paint.color = theme.textIntLight
                paint.alpha = 180
                paint.textSize = 22f * scale
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.textAlign = Paint.Align.LEFT
                canvas.drawText("•", leftX, rowY, paint)

                // Item Name (truncate safely if very long)
                paint.alpha = 240
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                var itemName = item.name
                if (itemName.length > 24) {
                    itemName = itemName.take(22) + "…"
                }
                canvas.drawText(itemName, leftX + (24f * scale), rowY, paint)

                // Item Amount
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.textAlign = Paint.Align.RIGHT
                val amountText = CurrencyFormatter.formatRupiah(item.amount)
                canvas.drawText(amountText, rightX, rowY, paint)

                // Light dashed/dotted ruled line below each item
                val rulePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = theme.textIntLight
                    alpha = 25
                    strokeWidth = 1f * scale
                    style = Paint.Style.STROKE
                }
                canvas.drawLine(leftX, rowY + (12f * scale), rightX, rowY + (12f * scale), rulePaint)
            }
        }

        // 7. Total Badge at Bottom of Note
        val totalBoxTop = noteBottom - (150f * scale)
        val totalBoxHeight = 70f * scale
        val totalBoxRect = RectF(noteLeft + (32f * scale), totalBoxTop, noteRight - (32f * scale), totalBoxTop + totalBoxHeight)

        val totalBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.colorIntDark
            alpha = 30
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(totalBoxRect, 16f * scale, 16f * scale, totalBoxPaint)

        // Total Label
        paint.color = theme.textIntLight
        paint.alpha = 230
        paint.textSize = 20f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("TOTAL PENGELUARAN", noteLeft + (52f * scale), totalBoxTop + (42f * scale), paint)

        // Total Value
        paint.textSize = 26f * scale
        paint.textAlign = Paint.Align.RIGHT
        val totalStr = CurrencyFormatter.formatRupiah(listWithItems.totalAmount)
        canvas.drawText(totalStr, noteRight - (52f * scale), totalBoxTop + (44f * scale), paint)

        // 8. Footer: Timestamp & App branding
        paint.color = 0xFF795548.toInt()
        paint.alpha = 160
        paint.textSize = 16f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textAlign = Paint.Align.CENTER
        val footerDate = "Dibuat: ${CurrencyFormatter.formatDateTime()} • My Finance Notes"
        canvas.drawText(footerDate, (baseWidth * scale) / 2f, noteBottom - (30f * scale), paint)

        return bitmap
    }

    private fun renderSummaryBoardBitmap(
        lists: List<ExpenseListWithItems>,
        grandTotal: Long,
        sheetNumber: Int,
        totalSheets: Int,
        scale: Float
    ): Bitmap {
        val baseWidth = 900f
        val baseHeight = 1260f
        val width = (baseWidth * scale).toInt()
        val height = (baseHeight * scale).toInt()

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Board background
        canvas.drawColor(0xFFEFEBE4.toInt())

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Board Header
        val headerY = 70f * scale
        paint.color = 0xFF3E2723.toInt()
        paint.textSize = 32f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("PAPAN CATATAN PENGELUARAN", (baseWidth * scale) / 2f, headerY, paint)

        // Grand Total Badge
        val badgeTop = 95f * scale
        val badgeRect = RectF((baseWidth / 2f - 240f) * scale, badgeTop, (baseWidth / 2f + 240f) * scale, badgeTop + (55f * scale))
        val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF2E7D32.toInt()
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(badgeRect, 28f * scale, 28f * scale, badgePaint)

        paint.color = 0xFFFFFFFF.toInt()
        paint.textSize = 22f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("Total Seluruh Catatan: ${CurrencyFormatter.formatRupiah(grandTotal)}", (baseWidth * scale) / 2f, badgeTop + (36f * scale), paint)

        // Cards on this sheet (up to 2 notes vertically stacked with beautiful layout)
        val cardHeight = 440f * scale
        val cardMargin = 40f * scale
        var currentCardTop = 180f * scale

        lists.forEach { listWithItems ->
            val theme = listWithItems.colorTheme
            val cardLeft = cardMargin
            val cardRight = (baseWidth * scale) - cardMargin
            val cardBottom = currentCardTop + cardHeight

            // Shadow
            val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x20000000
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(
                RectF(cardLeft + 6f * scale, currentCardTop + 8f * scale, cardRight + 6f * scale, cardBottom + 8f * scale),
                18f * scale, 18f * scale, shadowPaint
            )

            // Card body
            val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = theme.colorIntLight
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(
                RectF(cardLeft, currentCardTop, cardRight, cardBottom),
                18f * scale, 18f * scale, cardPaint
            )

            // Tape
            val tapeW = 120f * scale
            val tapeH = 32f * scale
            val tapeL = (baseWidth * scale - tapeW) / 2f
            val tapeT = currentCardTop - (12f * scale)
            val tapePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xAAFFE082.toInt()
            }
            canvas.drawRoundRect(RectF(tapeL, tapeT, tapeL + tapeW, tapeT + tapeH), 4f * scale, 4f * scale, tapePaint)

            // Card Header
            var innerY = currentCardTop + (42f * scale)
            paint.color = theme.textIntLight
            paint.textSize = 26f * scale
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText(listWithItems.list.title, cardLeft + (24f * scale), innerY, paint)

            paint.textAlign = Paint.Align.RIGHT
            paint.textSize = 22f * scale
            canvas.drawText(CurrencyFormatter.formatRupiah(listWithItems.totalAmount), cardRight - (24f * scale), innerY, paint)

            // Line
            innerY += 16f * scale
            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = theme.textIntLight
                alpha = 50
                strokeWidth = 1.5f * scale
                style = Paint.Style.STROKE
            }
            canvas.drawLine(cardLeft + (24f * scale), innerY, cardRight - (24f * scale), innerY, linePaint)

            // Items (up to 7 items on summary card)
            innerY += 32f * scale
            val itemsToShow = listWithItems.sortedItems.take(7)
            if (itemsToShow.isEmpty()) {
                paint.color = theme.textIntLight
                paint.alpha = 140
                paint.textSize = 18f * scale
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
                paint.textAlign = Paint.Align.LEFT
                canvas.drawText("Belum ada item", cardLeft + (24f * scale), innerY + 20f * scale, paint)
            } else {
                val step = 38f * scale
                itemsToShow.forEachIndexed { i, itm ->
                    val y = innerY + (i * step)
                    paint.color = theme.textIntLight
                    paint.alpha = 230
                    paint.textSize = 19f * scale
                    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    paint.textAlign = Paint.Align.LEFT
                    val name = if (itm.name.length > 28) itm.name.take(26) + "…" else itm.name
                    canvas.drawText("• $name", cardLeft + (24f * scale), y, paint)

                    paint.textAlign = Paint.Align.RIGHT
                    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    canvas.drawText(CurrencyFormatter.formatRupiah(itm.amount), cardRight - (24f * scale), y, paint)
                }

                if (listWithItems.sortedItems.size > 7) {
                    val remaining = listWithItems.sortedItems.size - 7
                    val y = innerY + (7 * step)
                    paint.alpha = 160
                    paint.textSize = 16f * scale
                    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
                    paint.textAlign = Paint.Align.LEFT
                    canvas.drawText("+ $remaining item lainnya", cardLeft + (24f * scale), y, paint)
                }
            }

            currentCardTop += cardHeight + (50f * scale)
        }

        // Sheet Page & Footer
        paint.color = 0xFF5D4037.toInt()
        paint.alpha = 170
        paint.textSize = 16f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textAlign = Paint.Align.CENTER
        val sheetText = if (totalSheets > 1) "Halaman $sheetNumber dari $totalSheets • " else ""
        canvas.drawText("$sheetText${CurrencyFormatter.formatDateTime()} • My Finance Notes", (baseWidth * scale) / 2f, (baseHeight - 30f) * scale, paint)

        return bitmap
    }

    suspend fun saveBitmapsToGallery(context: Context, bitmaps: List<Bitmap>, baseName: String): Result<List<Uri>> =
        withContext(Dispatchers.IO) {
            val savedUris = mutableListOf<Uri>()
            try {
                bitmaps.forEachIndexed { index, bitmap ->
                    val filename = if (bitmaps.size > 1) {
                        "${baseName}_hal_${index + 1}_${System.currentTimeMillis()}.png"
                    } else {
                        "${baseName}_${System.currentTimeMillis()}.png"
                    }

                    val uri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val contentValues = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                            put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/MyFinanceNotes")
                            put(MediaStore.MediaColumns.IS_PENDING, 1)
                        }
                        val imageUri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                        imageUri?.let { destUri ->
                            context.contentResolver.openOutputStream(destUri)?.use { out ->
                                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                            }
                            contentValues.clear()
                            contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                            context.contentResolver.update(destUri, contentValues, null, null)
                        }
                        imageUri
                    } else {
                        val imagesDir = File(
                            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                            "MyFinanceNotes"
                        ).apply { if (!exists()) mkdirs() }
                        val file = File(imagesDir, filename)
                        FileOutputStream(file).use { out ->
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                        }
                        val contentValues = ContentValues().apply {
                            put(MediaStore.Images.Media.DATA, file.absolutePath)
                            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        }
                        context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                    }

                    if (uri != null) {
                        savedUris.add(uri)
                    }
                }
                Result.success(savedUris)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun prepareBitmapsForSharing(context: Context, bitmaps: List<Bitmap>, baseName: String): Result<List<Uri>> =
        withContext(Dispatchers.IO) {
            val sharedUris = mutableListOf<Uri>()
            try {
                val imagesDir = File(context.cacheDir, "images").apply { if (!exists()) mkdirs() }
                bitmaps.forEachIndexed { index, bitmap ->
                    val filename = if (bitmaps.size > 1) {
                        "${baseName}_hal_${index + 1}.png"
                    } else {
                        "${baseName}.png"
                    }
                    val file = File(imagesDir, filename)
                    FileOutputStream(file).use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                    val authority = "${context.packageName}.fileprovider"
                    val uri = FileProvider.getUriForFile(context, authority, file)
                    sharedUris.add(uri)
                }
                Result.success(sharedUris)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun launchShareIntent(context: Context, uris: List<Uri>, title: String, toWhatsApp: Boolean = false) {
        if (uris.isEmpty()) return

        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uris[0])
                putExtra(Intent.EXTRA_TEXT, "Catatan Keuangan: $title\nDisimpan dengan My Finance Notes")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                putExtra(Intent.EXTRA_TEXT, "Catatan Keuangan: $title\nDisimpan dengan My Finance Notes")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }

        if (toWhatsApp) {
            intent.setPackage("com.whatsapp")
            try {
                context.startActivity(intent)
                return
            } catch (_: Exception) {
                // If WhatsApp is not installed, fallback to normal chooser
                intent.setPackage(null)
            }
        }

        val chooser = Intent.createChooser(intent, "Bagikan Catatan Keuangan")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
