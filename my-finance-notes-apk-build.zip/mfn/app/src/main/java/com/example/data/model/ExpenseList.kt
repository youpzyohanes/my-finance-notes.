package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expense_lists")
data class ExpenseList(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val colorTheme: String = NoteColorTheme.YELLOW.idName,
    val displayOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
