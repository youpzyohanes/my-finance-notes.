package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ExpenseItem
import com.example.data.model.ExpenseListWithItems
import com.example.data.model.NoteColorTheme
import com.example.export.ExportResolution
import com.example.ui.components.EmptyStateView
import com.example.ui.components.GrandTotalCard
import com.example.ui.components.StickyNoteCard
import com.example.ui.dialogs.AddEditItemDialog
import com.example.ui.dialogs.AddEditListDialog
import com.example.ui.dialogs.BackupRestoreDialog
import com.example.ui.dialogs.ConfirmDeleteDialog
import com.example.ui.dialogs.DownloadOptionsDialog
import com.example.ui.viewmodel.FinanceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: FinanceViewModel,
    isDarkTheme: Boolean,
    onToggleDarkTheme: () -> Unit
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val filteredLists by viewModel.filteredLists.collectAsStateWithLifecycle()
    val allLists by viewModel.rawLists.collectAsStateWithLifecycle()
    val grandTotal by viewModel.grandTotal.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isExporting by viewModel.isExporting.collectAsStateWithLifecycle()

    // Dialog state holders
    var showAddListDialog by remember { mutableStateOf(false) }
    var editListTarget by remember { mutableStateOf<ExpenseListWithItems?>(null) }
    var deleteListTarget by remember { mutableStateOf<ExpenseListWithItems?>(null) }

    var addItemTargetListId by remember { mutableStateOf<Long?>(null) }
    var editItemTarget by remember { mutableStateOf<ExpenseItem?>(null) }
    var deleteItemTarget by remember { mutableStateOf<ExpenseItem?>(null) }

    var downloadTargetNote by remember { mutableStateOf<ExpenseListWithItems?>(null) }
    var showDownloadAllDialog by remember { mutableStateOf(false) }
    var showBackupRestoreDialog by remember { mutableStateOf(false) }
    var showClearAllConfirm by remember { mutableStateOf(false) }
    var showResetDemoConfirm by remember { mutableStateOf(false) }

    var showTopMenu by remember { mutableStateOf(false) }

    // Listen to notifications
    LaunchedEffect(Unit) {
        viewModel.notification.collect { notif ->
            snackbarHostState.showSnackbar(notif.message)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NoteAlt,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "My Finance Notes",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                )
                            )
                            Text(
                                text = "Catatan Pengeluaran Pribadi",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                },
                actions = {
                    // Dark theme toggle
                    IconButton(
                        onClick = onToggleDarkTheme,
                        modifier = Modifier.testTag("theme_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = if (isDarkTheme) "Mode Terang" else "Mode Gelap"
                        )
                    }

                    // Top More Menu
                    Box {
                        IconButton(
                            onClick = { showTopMenu = true },
                            modifier = Modifier.testTag("top_menu_button")
                        ) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Menu Lainnya")
                        }

                        DropdownMenu(
                            expanded = showTopMenu,
                            onDismissRequest = { showTopMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Cadangkan & Pulihkan Data") },
                                onClick = {
                                    showTopMenu = false
                                    showBackupRestoreDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Muat Contoh Data") },
                                onClick = {
                                    showTopMenu = false
                                    showResetDemoConfirm = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Hapus Semua Catatan", color = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showTopMenu = false
                                    showClearAllConfirm = true
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddListDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Buat Catatan") },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("create_list_fab")
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = viewModel::onSearchQueryChange,
                placeholder = { Text("Cari daftar atau item pengeluaran...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Cari",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.onSearchQueryChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Hapus pencarian")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    focusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("search_input")
            )

            // Main Content: Sticky Notes List
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 90.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                // Grand Total Banner
                item {
                    GrandTotalCard(
                        grandTotal = grandTotal,
                        totalLists = allLists.size,
                        totalItems = allLists.sumOf { it.items.size },
                        onDownloadAll = { showDownloadAllDialog = true },
                        onBackupRestore = { showBackupRestoreDialog = true }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                if (filteredLists.isEmpty()) {
                    item {
                        if (allLists.isEmpty()) {
                            EmptyStateView(
                                onCreateFirst = { showAddListDialog = true },
                                onLoadDemo = { viewModel.resetToDemoData() }
                            )
                        } else {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp)
                            ) {
                                Text(
                                    text = "Tidak ditemukan catatan yang cocok dengan \"$searchQuery\"",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    itemsIndexed(
                        items = filteredLists,
                        key = { _, item -> item.list.id }
                    ) { index, listWithItems ->
                        StickyNoteCard(
                            listWithItems = listWithItems,
                            isDark = isDarkTheme,
                            canMoveUp = index > 0,
                            canMoveDown = index < filteredLists.size - 1,
                            onMoveUp = { viewModel.moveListUp(index) },
                            onMoveDown = { viewModel.moveListDown(index) },
                            onEditList = { editListTarget = listWithItems },
                            onDeleteList = { deleteListTarget = listWithItems },
                            onChangeColor = { newColor ->
                                viewModel.updateListColor(listWithItems.list.id, newColor)
                            },
                            onAddItem = { addItemTargetListId = listWithItems.list.id },
                            onEditItem = { item -> editItemTarget = item },
                            onDeleteItem = { item -> deleteItemTarget = item },
                            onIncrementItem = { item ->
                                viewModel.adjustItemAmount(item.id, item.amount, 10_000L)
                            },
                            onDecrementItem = { item ->
                                viewModel.adjustItemAmount(item.id, item.amount, -10_000L)
                            },
                            onMoveItemUp = { itemIndex ->
                                viewModel.moveItemUp(listWithItems, itemIndex)
                            },
                            onMoveItemDown = { itemIndex ->
                                viewModel.moveItemDown(listWithItems, itemIndex)
                            },
                            onDownloadNote = { downloadTargetNote = listWithItems }
                        )
                    }
                }
            }
        }
    }

    // --- Dialogs ---

    // 1. Add List Dialog
    if (showAddListDialog) {
        AddEditListDialog(
            isEdit = false,
            onConfirm = { title, color ->
                viewModel.addList(title, color)
            },
            onDismiss = { showAddListDialog = false }
        )
    }

    // 2. Edit List Dialog
    editListTarget?.let { target ->
        AddEditListDialog(
            initialTitle = target.list.title,
            initialColor = target.colorTheme,
            isEdit = true,
            onConfirm = { title, color ->
                viewModel.updateList(target.list.id, title, color)
            },
            onDismiss = { editListTarget = null }
        )
    }

    // 3. Delete List Confirmation
    deleteListTarget?.let { target ->
        ConfirmDeleteDialog(
            title = "Hapus Daftar Catatan?",
            message = "Apakah Anda yakin ingin menghapus '${target.list.title}' berserta ${target.items.size} item pengeluaran di dalamnya? Tindakan ini tidak dapat dibatalkan.",
            onConfirm = {
                viewModel.deleteList(target.list.id, target.list.title)
            },
            onDismiss = { deleteListTarget = null }
        )
    }

    // 4. Add Item Dialog
    addItemTargetListId?.let { listId ->
        AddEditItemDialog(
            isEdit = false,
            onConfirm = { name, amount ->
                viewModel.addItem(listId, name, amount)
            },
            onDismiss = { addItemTargetListId = null }
        )
    }

    // 5. Edit Item Dialog
    editItemTarget?.let { item ->
        AddEditItemDialog(
            initialName = item.name,
            initialAmount = item.amount,
            isEdit = true,
            onConfirm = { name, amount ->
                viewModel.updateItem(item.id, item.listId, name, amount, item.displayOrder)
            },
            onDismiss = { editItemTarget = null }
        )
    }

    // 6. Delete Item Confirmation
    deleteItemTarget?.let { item ->
        ConfirmDeleteDialog(
            title = "Hapus Item Pengeluaran?",
            message = "Apakah Anda yakin ingin menghapus pengeluaran '${item.name}'?",
            onConfirm = {
                viewModel.deleteItem(item.id, item.name)
            },
            onDismiss = { deleteItemTarget = null }
        )
    }

    // 7. Download Single Note Dialog
    downloadTargetNote?.let { target ->
        DownloadOptionsDialog(
            title = target.list.title,
            subtitle = "Total ${target.items.size} item pengeluaran • ${com.example.util.CurrencyFormatter.formatRupiah(target.totalAmount)}",
            isAllNotes = false,
            isExporting = isExporting,
            onDownload = { resolution, saveToGallery, shareToWhatsApp ->
                viewModel.downloadSingleNote(context, target, resolution, saveToGallery, shareToWhatsApp)
                downloadTargetNote = null
            },
            onDismiss = { downloadTargetNote = null }
        )
    }

    // 8. Download All Notes Dialog
    if (showDownloadAllDialog) {
        DownloadOptionsDialog(
            title = "Semua Catatan",
            subtitle = "Total ${allLists.size} daftar catatan • ${com.example.util.CurrencyFormatter.formatRupiah(grandTotal)}",
            isAllNotes = true,
            isExporting = isExporting,
            onDownload = { resolution, saveToGallery, shareToWhatsApp ->
                viewModel.downloadAllNotes(context, resolution, saveToGallery, shareToWhatsApp)
                showDownloadAllDialog = false
            },
            onDismiss = { showDownloadAllDialog = false }
        )
    }

    // 9. Backup & Restore Dialog
    if (showBackupRestoreDialog) {
        BackupRestoreDialog(
            jsonBackupText = viewModel.getBackupJson(),
            onRestore = { jsonString, overwrite ->
                viewModel.restoreBackup(jsonString, overwrite) { success, msg -> }
            },
            onDismiss = { showBackupRestoreDialog = false }
        )
    }

    // 10. Clear All Data Confirmation
    if (showClearAllConfirm) {
        ConfirmDeleteDialog(
            title = "Hapus Semua Data?",
            message = "Seluruh daftar dan item pengeluaran akan dihapus secara permanen dari perangkat. Pastikan Anda telah mencadangkan data jika masih diperlukan.",
            onConfirm = {
                viewModel.clearAllData()
            },
            onDismiss = { showClearAllConfirm = false }
        )
    }

    // 11. Reset Demo Data Confirmation
    if (showResetDemoConfirm) {
        ConfirmDeleteDialog(
            title = "Muat Ulang Contoh Data?",
            message = "Data saat ini akan digantikan dengan contoh awal demonstrasi aplikasi.",
            onConfirm = {
                viewModel.resetToDemoData()
            },
            onDismiss = { showResetDemoConfirm = false }
        )
    }
}
