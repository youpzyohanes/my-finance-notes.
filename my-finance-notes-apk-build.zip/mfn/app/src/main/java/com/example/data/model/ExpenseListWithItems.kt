package com.example.data.model

import androidx.room.Embedded
import androidx.room.Relation

data class ExpenseListWithItems(
    @Embedded
    val list: ExpenseList,
    @Relation(
        parentColumn = "id",
        entityColumn = "listId"
    )
    val items: List<ExpenseItem>
) {
    val totalAmount: Long
        get() = items.sumOf { it.amount }

    val colorTheme: NoteColorTheme
        get() = NoteColorTheme.fromId(list.colorTheme)

    val sortedItems: List<ExpenseItem>
        get() = items.sortedWith(compareBy({ it.displayOrder }, { it.id }))
}
