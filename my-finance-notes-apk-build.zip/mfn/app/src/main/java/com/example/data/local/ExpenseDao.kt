package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.ExpenseItem
import com.example.data.model.ExpenseList
import com.example.data.model.ExpenseListWithItems
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {

    @Transaction
    @Query("SELECT * FROM expense_lists ORDER BY displayOrder ASC, id ASC")
    fun getAllListsWithItems(): Flow<List<ExpenseListWithItems>>

    @Transaction
    @Query("SELECT * FROM expense_lists WHERE id = :listId LIMIT 1")
    suspend fun getListWithItemsById(listId: Long): ExpenseListWithItems?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertList(list: ExpenseList): Long

    @Update
    suspend fun updateList(list: ExpenseList)

    @Delete
    suspend fun deleteList(list: ExpenseList)

    @Query("DELETE FROM expense_lists WHERE id = :listId")
    suspend fun deleteListById(listId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: ExpenseItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<ExpenseItem>): List<Long>

    @Update
    suspend fun updateItem(item: ExpenseItem)

    @Delete
    suspend fun deleteItem(item: ExpenseItem)

    @Query("DELETE FROM expense_items WHERE id = :itemId")
    suspend fun deleteItemById(itemId: Long)

    @Query("UPDATE expense_items SET amount = :newAmount WHERE id = :itemId")
    suspend fun updateItemAmount(itemId: Long, newAmount: Long)

    @Query("UPDATE expense_lists SET colorTheme = :colorName WHERE id = :listId")
    suspend fun updateListColor(listId: Long, colorName: String)

    @Query("UPDATE expense_lists SET title = :newTitle WHERE id = :listId")
    suspend fun updateListTitle(listId: Long, newTitle: String)

    @Query("UPDATE expense_lists SET displayOrder = :order WHERE id = :listId")
    suspend fun updateListOrder(listId: Long, order: Int)

    @Query("UPDATE expense_items SET displayOrder = :order WHERE id = :itemId")
    suspend fun updateItemOrder(itemId: Long, order: Int)

    @Query("DELETE FROM expense_lists")
    suspend fun clearAllLists()

    @Query("DELETE FROM expense_items")
    suspend fun clearAllItems()

    @Transaction
    suspend fun clearAllData() {
        clearAllItems()
        clearAllLists()
    }
}
