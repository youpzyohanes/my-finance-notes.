package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ExpenseItem
import com.example.data.model.ExpenseList
import com.example.data.model.NoteColorTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [ExpenseList::class, ExpenseItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun expenseDao(): ExpenseDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "my_finance_notes.db"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Seed initial example data for first launch demonstration
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialDemoData(database.expenseDao())
                    }
                }
            }
        }

        suspend fun populateInitialDemoData(dao: ExpenseDao) {
            val list1Id = dao.insertList(
                ExpenseList(
                    title = "Kebutuhan Harian",
                    colorTheme = NoteColorTheme.YELLOW.idName,
                    displayOrder = 0
                )
            )
            dao.insertItem(ExpenseItem(listId = list1Id, name = "Beras & Sembako", amount = 125000, displayOrder = 0))
            dao.insertItem(ExpenseItem(listId = list1Id, name = "Lauk Pauk & Sayur", amount = 75000, displayOrder = 1))
            dao.insertItem(ExpenseItem(listId = list1Id, name = "Galon Air & Gas", amount = 42000, displayOrder = 2))

            val list2Id = dao.insertList(
                ExpenseList(
                    title = "Tagihan & Cicilan",
                    colorTheme = NoteColorTheme.BLUE.idName,
                    displayOrder = 1
                )
            )
            dao.insertItem(ExpenseItem(listId = list2Id, name = "Listrik PLN Token", amount = 200000, displayOrder = 0))
            dao.insertItem(ExpenseItem(listId = list2Id, name = "Paket Internet & Wi-Fi", amount = 150000, displayOrder = 1))

            val list3Id = dao.insertList(
                ExpenseList(
                    title = "Transportasi & Bensin",
                    colorTheme = NoteColorTheme.MINT.idName,
                    displayOrder = 2
                )
            )
            dao.insertItem(ExpenseItem(listId = list3Id, name = "Bensin Motor", amount = 50000, displayOrder = 0))
            dao.insertItem(ExpenseItem(listId = list3Id, name = "Parkir & Tol", amount = 20000, displayOrder = 1))
        }
    }
}
